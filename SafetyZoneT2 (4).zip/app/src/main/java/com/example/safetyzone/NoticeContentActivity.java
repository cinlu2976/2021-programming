package com.example.safetyzone;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class NoticeContentActivity extends AppCompatActivity {
    TextView title,regId,content;
    String titles,regIds,contents,id,num;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notice_content);

        Button btnBack = findViewById(R.id.buttonBack);
        Button btnUpdate = findViewById(R.id.btnUpdate);

        Intent intent = getIntent();
        titles = intent.getStringExtra("title");
        regIds = intent.getStringExtra("writer");
        contents = intent.getStringExtra("content");
        id = intent.getStringExtra("id");
        num = intent.getStringExtra("noticeNumber");




        title = findViewById(R.id.textTitleSet);
        regId = findViewById(R.id.textRegId);
        content = findViewById(R.id.textContent);

        title.setText(titles);
        regId.setText(regIds);
        content.setText(contents);

        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        if(id.equals("admin"))
        {
            btnUpdate.setVisibility(View.VISIBLE);
        }
        else
        {
            btnUpdate.setVisibility(View.INVISIBLE);
        }

        btnUpdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent it = new Intent(NoticeContentActivity.this, NoticeUpdateActivity.class);
                it.putExtra("title",titles);
                it.putExtra("content",contents);
                it.putExtra("id",id);
                it.putExtra("num",num);
                startActivity(it);
//                finish();
            }
        });
    }

}