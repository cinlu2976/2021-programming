package com.example.safetyzone;

import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;

import com.example.safetyzone.api.ApiUtil;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;

public class Fragment2 extends Fragment {
    //공지사항 프래그먼트
    Button btnRegister,btnRef;
    NoticeRegisterActivity noticeRegisterActivity;
    MainActivity mainActivity;
    String checkId,result;
    Boolean success;

    //리스트뷰 세팅.
    private ListView mListView;
    private SimpleAdapter mSAdapter;
    private ArrayList<HashMap<String,String>> mListData;

    //mListData 에서 데이터를 받아옴.
    //각 항목을 알려주기 위해. 그때그때.
    private ArrayList<String> noticeTitle;
    private ArrayList<String> noticeContent;
    private ArrayList<String> noticeRegId;
    private ArrayList<String> noticeRegDate;
    private ArrayList<Integer> noticeNum;
    private ArrayList<String> noticeWriter;

    int first =1;


    public void top() {
        HashMap<String,String> hitem = new HashMap<>();
        hitem.put("num","번호");
        hitem.put("title","제목");
        hitem.put("writer","작성자");
        hitem.put("date","등록일");
        mListData.add(hitem);
        mListView.setAdapter(mSAdapter);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment

        ViewGroup rootView = (ViewGroup)inflater.inflate(R.layout.fragment_fragment2,container,false);

        btnRegister = (Button)rootView.findViewById(R.id.buttonRegister);
        checkId = getArguments().getString("id");
        mListView = (ListView)rootView.findViewById(R.id.listView);
        btnRef = (Button)rootView.findViewById(R.id.buttonRef);

        noticeTitle = new ArrayList<>();
        noticeContent = new ArrayList<>();
        noticeRegId = new ArrayList<>();
        noticeRegDate = new ArrayList<>();
        noticeNum = new ArrayList<>();
        noticeWriter = new ArrayList<>();




        mListData = new ArrayList();
        mSAdapter = new SimpleAdapter(getActivity(),mListData,R.layout.custom_listview,new String[]{"num","title","writer","date"},
                new int[]{R.id.textNumSet,R.id.textTitleSet,R.id.textWriterSet,R.id.textDateSet});



        top();



        btnRef.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Thread th = new Thread(new Runnable() {
                    @Override
                    public void run() {

                        JSONObject json = new JSONObject();
                        try {
                            json.put("size",40);
                            json.put("start", 0);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
//                       String c = json.toString();
//                       System.out.println(c);

                        JSONObject response = ApiUtil.callApi(json.toString(),
                                "GET",
                                "/notice.json",
                                true);

                        try {
                            if(response != null){
                                JSONArray jsonArray = response.getJSONArray("list");

                                if(jsonArray != null) {
                                    int len = jsonArray.length();
                                    for (int i=len-1 ;i>=0;i--) {
                                        JSONObject jsonObject = jsonArray.getJSONObject(i);

                                        //JSONObject 변환.
                                        int num = jsonObject.getInt("noticeIdx");
                                        String nums = Integer.toString(num);
                                        String title = jsonObject.getString("noticeTitle");
                                        String content = jsonObject.getString("noticeContent");
                                        String writer = jsonObject.getString("regId");
                                        String regDatetime = jsonObject.getString("regDatetime");
                                        String regSplit[] = regDatetime.split("T");
                                        String regDate = regSplit[0];

                                        //각 항목들 따로 저장.
                                        noticeNum.add(num);
                                        noticeTitle.add(title);
                                        noticeContent.add(content);
                                        noticeWriter.add(writer);
                                        noticeRegDate.add(regDate);

                                        //리스트뷰에 추가.
                                        HashMap<String, String> hitem = new HashMap<>();
                                        hitem.put("num",Integer.toString(i+1));
                                        hitem.put("title",title);
                                        hitem.put("content",content);
                                        hitem.put("writer",writer);
                                        hitem.put("date",regDate);
                                        mListData.add(hitem);
                                    }

                                }
                                success = Boolean.TRUE;
                            }
                            else{

                                success = Boolean.FALSE;
                            }
                            getActivity().runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    if(first ==1) //처음 동작시.
                                    {
                                        mSAdapter.notifyDataSetChanged();
                                        mListView.setAdapter(mSAdapter);
                                        btnRef.setText("닫기");
                                        first =2;
                                    }
                                    else // 그 다음 버튼 클릭 동작시 값들 다 초기화.
                                    {
                                        mListData.clear();
                                        noticeNum.clear();
                                        noticeTitle.clear();
                                        noticeContent.clear();
                                        noticeWriter.clear();
                                        noticeRegDate.clear();

                                        mSAdapter.notifyDataSetChanged();
                                        mListView.setAdapter(mSAdapter);
                                        top();
                                        btnRef.setText("조회");
                                        first =1;
                                    }


                                }
                            });
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                });
                th.start();
            }
        });




        //리스트뷰 항목 클릭 이벤트.
        mListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                HashMap <String,String> hashMap = new HashMap<>();

                Intent it = new Intent(getActivity(),NoticeContentActivity.class);
                //클릭된 항목의 데이터 받아오기 위해서.
                String title = noticeTitle.get(position-1);
                String writer = noticeWriter.get(position-1);
                String content = noticeContent.get(position-1);
                String number = noticeNum.get(position - 1).toString();



                it.putExtra("title",title);
                it.putExtra("writer",writer);
                it.putExtra("content",content);
                it.putExtra("id",checkId);
                it.putExtra("noticeNumber",number);
//                it.putExtra("noticeNumber",number);
                startActivity(it);
            }
        });




        //관리자이면 공지사항 등록 버튼 보이게
        if(checkId.equals("admin"))
        {
            btnRegister.setVisibility(View.VISIBLE);
        }
        else
        {
            btnRegister.setVisibility(View.INVISIBLE);
        }

        //공지사항 등록 클릭 이벤트.
        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent it = new Intent(getActivity(),NoticeRegisterActivity.class);
                it.putExtra("checkId",checkId);
                startActivity(it);
            }
        });




        return rootView;

    }




}