package com.example.safetyzone;

import android.content.ContentValues;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;


import com.example.safetyzone.api.ApiUtil;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;



public class LoginActivity extends AppCompatActivity {
    EditText editTextID, editTextPwd;
    String result= "";
    String login = "";
    String userCheck;
    String idCheck;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);


        Button btnSign = (Button)findViewById(R.id.buttonSign);
        editTextID = (EditText)findViewById(R.id.editTextID);
        editTextPwd = (EditText)findViewById(R.id.editTextPassword);





        btnSign.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(LoginActivity.this, SignActivity.class);
                startActivity(intent);
                finish();
            }
        });
    }





    public void login(View v) {
        Thread th = new Thread(new Runnable() {
            @Override
            public void run() {

                JSONObject json = new JSONObject();
                try {
                    json.put("accountId", editTextID.getText().toString());
                    json.put("pwd", editTextPwd.getText().toString());
                    json.put("push", "TEST_PUSH_KEY");
                } catch (JSONException e) {
                    e.printStackTrace();
                }

                JSONObject response = ApiUtil.callApi(json.toString(),
                        "POST",
                        "/login.json",
                        true);

                try {

                    if(response != null){
                        JSONObject data = response.getJSONObject("data");
                        String name = data.getString("accountName");
                        String accountId = data.getString("accountId");
                        userCheck = data.getString("authCd");
                        idCheck = data.getString("accountId");
                        result = name + "님 환영합니다.";
                        login = "OK";
                    }
                    else{
                        result="아이디 또는 비밀번호가 일치하지 않습니다.";
                        login = "False";
                    }
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(getApplicationContext(),result+"권한코드:"+userCheck,Toast.LENGTH_LONG).show();
                            if(login.equals("OK")){
                                Intent intent = new Intent(LoginActivity.this, MainActivity.class);
                                intent.putExtra("check",userCheck);
                                intent.putExtra("checkId",idCheck);
                                startActivity(intent);
                                finish();
                            }

                        }
                    });
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        });
        th.start();
    }




}