package com.example.safetyzone;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.safetyzone.api.ApiUtil;

import org.json.JSONException;
import org.json.JSONObject;

public class NoticeUpdateActivity extends AppCompatActivity {
    TextView regId;
    EditText title,content;
    String titles,regIds,contents,id,num,result;
    Boolean success;
    int numT;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notice_update);

        Intent it = getIntent();
        titles = it.getStringExtra("title");
        contents = it.getStringExtra("content");
        id = it.getStringExtra("id");
        num = it.getStringExtra("num");

        numT =Integer.parseInt(num);

        regId = findViewById(R.id.textRegId2);
        title = findViewById(R.id.textUpdateTitle);
        content = findViewById(R.id.textUpdateContent);

        regId.setText(id);
        title.setText(titles);
        content.setText(contents);
    }

    public void update(View v) {
        Thread th = new Thread(new Runnable() {
            @Override
            public void run() {
                JSONObject json = new JSONObject();

                try {
                    json.put("noticeIdx",numT);
                    json.put("noticeTitle", title.getText().toString());
                    json.put("noticeContent", content.getText().toString());
                    json.put("accountId", id);

                } catch (JSONException e) {
                    e.printStackTrace();
                }

                JSONObject response = ApiUtil.callApi(json.toString(),
                        "PUT",
                        "/notice.json",
                        true);

                try {
                    if(response != null){
                        result = "공지사항 수정을 완료 하였습니다.";
                        success = Boolean.TRUE;
                    }
                    else{
                        result="공지사항 수정 실패.";
                        success = Boolean.FALSE;
                    }
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(getApplicationContext(),result,Toast.LENGTH_LONG).show();
                            if(success.equals(Boolean.TRUE)){
                                Toast.makeText(getApplicationContext(),result,Toast.LENGTH_LONG);
                                onBackPressed();
                            }

                        }
                    });
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
        th.start();
    }


    public void delete(View v) {
        Thread th = new Thread(new Runnable() {
            @Override
            public void run() {
                JSONObject json = new JSONObject();

                try {
                    json.put("accountId", id);
                    json.put("noticeIdx",numT);
                } catch (JSONException e) {
                    e.printStackTrace();
                }

                JSONObject response = ApiUtil.callApi(json.toString(),
                        "DELETE",
                        "/notice.json",
                        true);

                try {
                    if(response != null){
                        result = "삭제";
                        success = Boolean.TRUE;
                    }
                    else{
                        result="공지사항 삭제실패.";
                        success = Boolean.FALSE;
                    }
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(getApplicationContext(),result,Toast.LENGTH_LONG).show();
                            if(success.equals(Boolean.TRUE)){
                                Toast.makeText(getApplicationContext(),result,Toast.LENGTH_LONG);
                                onBackPressed();
                            }

                        }
                    });
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
        th.start();
    }
}